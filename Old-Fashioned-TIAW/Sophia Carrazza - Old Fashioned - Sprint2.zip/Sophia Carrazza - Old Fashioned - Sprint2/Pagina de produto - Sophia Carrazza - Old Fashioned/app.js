const ITEMS = [
    {
        id: 1,
        name: 'Tênis Confortável Cano Baixo',
        price: 84.99,
        off: 100.99,
        description:'Tênis beige e branco, justo e confortável. Excelente para sair de dia e em encontros casuais.',
        image1: 'images/image-product-1.jpg',
        thumb1:'images/image-product-1.jpg',
        thumb2:'images/image-product-2.jpg',
        thumb3:'images/image-product-3.jpg',
        thumb4:'images/image-product-4.jpg',
        qty: 1

    },
  
]
var img1 = "images/image-product-1.jpg";
var img2 = "images/image-product-2.jpg";
var img3 = "images/image-product-3.jpg";
var img4 = "images/image-product-4.jpg";

const openrenner = document.getElementById('renner');
const opencea = document.getElementById('cea');
const openriachuelo = document.getElementById('riachuelo');

const openBtn = document.getElementById('open_cart_btn');
const cart = document.getElementById('sidecart');
const closeBtn = document.getElementById('close_btn');
const backdrop = document.querySelector('.backdrop');
const itemsEL = document.querySelector('.items');
const cartItems = document.querySelector('.cart_items');
const itemsNumber = document.getElementById('items_num');
const subtotalPrice = document.getElementById('subtotal_price');
const addtocart = document.querySelector('.button');

let cart_data = [];


let saved_cart_item = [];

let favorito = []

openBtn.addEventListener('click', openCart)
closeBtn.addEventListener('click', closeCart)
backdrop.addEventListener('click', closeCart)

openrenner.addEventListener('click', openRenner)
opencea.addEventListener('click', openCEA)
openriachuelo.addEventListener('click', openRiachuelo)


//Salvar nos favoritos
document.querySelector(".heart_button").onclick = function () {
    const itemId = ITEMS[0].id; // Defina o id do item aqui
    // Restante do código aqui
    const favoritos = JSON.parse(localStorage.getItem('favorito')) || [];

   if (favoritos.includes(itemId)) {
    
    alert('Este item já está nos favoritos!');
    
  } else {
    const button1 = document.querySelector('.heart_button');
    button1.style.display = 'none';

    const button2 = document.querySelector('.heart_button2');
    button2.style.display = 'flex';

    favoritos.push(itemId);
    localStorage.setItem('favorito', JSON.stringify(favoritos));
    alert('Produto salvo nos favoritos!');

    
  }
}

document.addEventListener('DOMContentLoaded', () => {
    const itemId = ITEMS[0].id; // defina o id do item aqui
    const favoritos = JSON.parse(localStorage.getItem('favorito')) || [];
    const button1 = document.querySelector('.heart_button');
    const button2 = document.querySelector('.heart_button2');
  
    if (favoritos.includes(itemId)) {
      button1.style.display = 'none';
      button2.style.display = 'flex';
    } else {
      button1.style.display = 'flex';
      button2.style.display = 'none';
    }
  });


var favoritos= JSON.parse(localStorage.getItem('favorito')) || [];



// Trocar Imagem do Produto
function trocarimga() {
    document.getElementById("figura").src = img1;
    let aux = img1;
}
function trocarimgb() {
    document.getElementById("figura").src = img2;
    let aux = img2;
}
function trocarimgc() {
    document.getElementById("figura").src = img3;
    let aux = img2;
}
function trocarimgd() {
    document.getElementById("figura").src = img4;
    let aux = img2;
}

renderItems()
renderCartItems()

// Open Stores
function openRenner() {
    window.open('https://www.lojasrenner.com.br/p/tenis-cano-baixo-com-recortes-e-sola-bicolor/-/A-717647194-br.lr?sku=717647240')
}
function openCEA() {
    window.open('https://www.cea.com.br/tenis-casual-com-recortes-oneself-bege-1052487-bege/p')
}
function openRiachuelo() {
    window.open('https://www.riachuelo.com.br/tenis-cano-baixo-chuck-taylor-bege-converse-all-star-14973294_sku')
}

// Open Cart
function openCart() {
    cart.classList.add('open');
    backdrop.style.display = 'block';
    setTimeout(() => {
    backdrop.classList.add('show');
    }, 0);
}

// Close Cart
function closeCart() {
    cart.classList.remove('open');
    backdrop.classList.remove('show');
    setTimeout(() => {
        backdrop.style.display = 'none';
        }, 500);
}


//Add Items to Cart
function addItem(idx, itemId) {
    // find same items
    const foundedItem = cart_data.find(
        (item) => item.id.toString() === itemId.toString()
        )
    if(foundedItem){
        //increase item qty
        increaseQty(itemId)
        
    updateCart()
    } else {
      cart_data.push(ITEMS[idx])
      .qty++;

        // Adiciona o item ao localStorage
      saved_cart_item.push(itemId);
      localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));
      alert('Seu produto foi adicionado ao carrinho com sucesso');
    }
    updateCart();
    openCart(); 



}
  
// Recupera o array de produtos do localStorage, ou cria um novo array se ele não existir ainda
var savedcartitem= JSON.parse(localStorage.getItem('saved_cart_item')) || [];

// recupera o carrinho do localStorage
//function getCart() {
//  return JSON.parse(localStorage.getItem('cart')) || [];
//}


// Render Items
// Remove Cart Items
function removeCartItem(itemId) {
    cart_data = cart_data.filter((item) => item.id != itemId)
     // encontra o índice do item no array saved_cart_item
  const index = saved_cart_item.indexOf(itemId);

  if (index !== -1) {
    // Remove o item do array saved_cart_item
    saved_cart_item.splice(index, 1);

    // Remove o item do localStorage
    localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));

    // Remove o item do array cart_data
    cart_data = cart_data.filter((item) => item.id.toString() !== itemId.toString());

    updateCart()
  }



    updateCart()
}

// Increase Qty
function increaseQty(itemId) {
    const item = cart_data.find((item) => item.id == itemId)
    item.qty++;
   // Adiciona o item ao localStorage
   saved_cart_item.push(itemId);
   localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));
   
  updateCart()
}

// Decrease Qty
function decreaseQty(itemId) {
//    cart_data = cart_data.map((item) => 
//    item.id.toString() === itemId.toString()
//    ? {...item, qty: item.qty > 1 ? item.qty -1 : item.qty}
//    : item)

    const item = cart_data.find((item) => item.id == itemId)
    item.qty = Math.max(item.qty - 1, 0); 

 // encontra o índice do item no array saved_cart_item
 const index = saved_cart_item.indexOf(itemId);

 if (index !== -1) {
   // Remove o item do array saved_cart_item
   saved_cart_item.splice(index, 1);

   // Remove o item do localStorage
   localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));

   
   updateCart()
 }

    updateCart()

}
document.addEventListener('DOMContentLoaded', () => {
    const saved_cart_item = JSON.parse(localStorage.getItem('saved_cart_item')) || [];
    itemsNumber.innerText = saved_cart_item.length;
});

// Calculate Items Number
function calculateItemsNum() {
    let itemsCount = 0

    cart_data.forEach((item) => (itemsCount += item.qty))

    itemsNumber.innerText = itemsCount
}
// Calculate Subtotal Price
function  calcSubtotalPrice() {
    let subtotal = 0
    cart_data.forEach((item) => (subtotal += item.price * item.qty))

    subtotalPrice.innerText = subtotal.toFixed(2);
}  
// Render Items
function renderItems() {
    ITEMS.forEach((item, idx) =>{
        
        const itemEl = document.createElement('div');
        itemEl.classList.add('item');
        //itemEl.onclick = () => addItem(idx, item.id);
        //addtocart.onclick = () => addItem(idx, item.id);
        itemEl.innerHTML = `
        <div class="select-image">
                            <div class="product_name">
                            <h5>Old Fashioned</h5>
                            <h1>${item.name}</h1>
                            
                            </div>
                      
                            <img id="figura" src="${item.image1}" alt="">
                        </div>
                        <div class="thumbnails">
                            <div class="thumbnail">
                                <button onclick="trocarimga()" class="thumb_btn"><img id="thumb1" src="${item.thumb1}" alt=""></button>
                            </div>
                            <div class="thumbnail">
                                <button onclick="trocarimgb()" class="thumb_btn"><img id="thumb1" src="${item.thumb2}" alt=""></button>
                            </div>
                            <div class="thumbnail">
                                <button onclick="trocarimgc()" class="thumb_btn"><img id="thumb2" src="${item.thumb3}" alt=""></button>
                            </div>  
                            <div class="thumbnail">
                                <button onclick="trocarimgd()" class="thumb_btn"><img id="thumb3" src="${item.thumb4}" alt=""></button>
                            </div> 
                            
                        </div>
                        <div class="descricao">
                            <h1>Descrição do produto:</h1>
                            <p>${item.description}</p>
                            
                            </div>
                            
                            <div class="compra">
                            <h1>Compra:</h1>
                                <div class="prices">
                                    <span class="price">R$${item.price}</span>
                                <s class="off">${item.off}</s>
                                </div>
                                
                            </div>
                            <div class="cartbtn">
                                <button class="button add-to-cart-btn"><img src="images/icon-cart.svg" alt="">Adicionar ao carrinho</button>
                            </div>
                            </div>
                            <div class="line2"></div>
        `
        itemsEL.appendChild(itemEl);
        document.querySelectorAll('.add-to-cart-btn').forEach((btn, idx) => {
            btn.onclick = () => addItem(idx, item.id);
            
    })
})
}

//Display / Render Cart Items
function renderCartItems(){
    //remove everything from cart
    cartItems.innerHTML = '';
    // add new data
    cart_data.forEach((item) =>{
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart_item');
        cartItem.innerHTML = `  
        <div class="remove_item" onclick="removeCartItem(${item.id})">
                        <span>&times;</span>
                    </div>
                    <div class="item_img">
                        <img src="${item.image1}" alt="">
                    </div>
                    <div class="item_details">
                        <p>${item.name}</p>
                        <strong>$${item.price}</strong>
                        <div class="qty">
                            <span onclick="decreaseQty(${item.id})">-</span>
                            <strong>${item.qty}</strong>
                            <span onclick="increaseQty(${item.id})">+</span>
                        </div>
                    </div>
        `
        cartItems.appendChild(cartItem);
})
}



function updateCart(){
    //render cart items with updated data
    renderCartItems();
    //update items number in cart
    calculateItemsNum();
    //update subtotal price
    calcSubtotalPrice();
}

