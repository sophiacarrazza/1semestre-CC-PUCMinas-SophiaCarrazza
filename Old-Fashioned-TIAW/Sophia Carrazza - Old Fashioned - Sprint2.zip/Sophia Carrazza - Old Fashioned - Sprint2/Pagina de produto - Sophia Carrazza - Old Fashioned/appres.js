const ITEMS = [
    {
        id: 1,
        name: 'Tênis Confortável Cano Baixo',
        price: 84.99,
        off: 100.99,
        description:'Tênis beige e branco, justo e confortável. Excelente para sair de dia e em encontros casuais.',
        image1: 'images/image-product-1.jpg',
        thumb1:'images/image-product-1.jpg',
        thumb2:'images/image-product-2.jpg',
        thumb3:'images/image-product-3.jpg',
        thumb4:'images/image-product-4.jpg',
        qty: 1

    },
    {
        id: 2,
        name: 'Sapatenis Branco e Beige',
        price: 150.99,
        off: 200.99,
        description:'Sapatênis beige e branco, justo e confortável. Excelente para sair de dia e em encontros casuais.',
        
        image1: 'images/image-product-2.jpg',
        thumb1:'images/image-product-1.jpg',
        thumb2:'images/image-product-2.jpg',
        thumb3:'images/image-product-3.jpg',
        thumb4:'images/image-product-4.jpg',
        qty: 1

    },
    {
        id: 3,
        name: 'Sapato Social Feminino',
        description:'Sapato social feminino branco, justo e confortável. Excelente para sair de dia e em encontros casuais.',
        
        price: 204.99,
        off: 350.99,
        image1: 'images/image-product-3.jpg',
        thumb1:'images/image-product-1.jpg',
        thumb2:'images/image-product-2.jpg',
        thumb3:'images/image-product-3.jpg',
        thumb4:'images/image-product-4.jpg',
        qty: 1

    },
    {
        id: 4,
        name: 'Cano Baixo para Corrida',
        description:'Tênis cano baixo de corrida, ergonômico. Excelente para sair de dia e em encontros casuais.',
        
        price: 139.99,
        off: 200.99,
        image1: 'images/image-product-4.jpg',
        thumb1:'images/image-product-1.jpg',
        thumb2:'images/image-product-2.jpg',
        thumb3:'images/image-product-3.jpg',
        thumb4:'images/image-product-4.jpg',
        qty: 1

    },
]

const openBtn = document.getElementById('open_cart_btn');
const cart = document.getElementById('sidecart');
const closeBtn = document.getElementById('close_btn');
const backdrop = document.querySelector('.backdrop');
const itemsEL = document.querySelector('.items');
const cartItems = document.querySelector('.cart_items');
const itemsNumber = document.getElementById('items_num');
const subtotalPrice = document.getElementById('subtotal_price');

let cart_data = []

openBtn.addEventListener('click', openCart)
closeBtn.addEventListener('click', closeCart)
backdrop.addEventListener('click', closeCart)

renderItems()
renderCartItems()

// Open Cart
function openCart() {
    cart.classList.add('open');
    backdrop.style.display = 'block';
    setTimeout(() => {
    backdrop.classList.add('show');
    }, 0);
}

// Close Cart
function closeCart() {
    cart.classList.remove('open');
    backdrop.classList.remove('show');
    setTimeout(() => {
        backdrop.style.display = 'none';
        }, 500);
}

let saved_cart_item = [];
// Recupera o array de produtos do localStorage, ou cria um novo array se ele não existir ainda
var savedcartitem= JSON.parse(localStorage.getItem('saved_cart_item')) || [];

//Add Items to Cart
function addItem(idx, itemId) {
   // find same items
   const foundedItem = cart_data.find(
    (item) => item.id.toString() === itemId.toString()
    )
if(foundedItem){
    //increase item qty
    increaseQty(itemId)
    
updateCart()
} else {
  cart_data.push(ITEMS[idx])
  
    // Adiciona o item ao localStorage
  saved_cart_item.push(itemId);
  localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));
  alert('Seu produto foi adicionado ao carrinho com sucesso');
}
updateCart();
openCart(); 


}
// Remove Cart Items
function removeCartItem(itemId) {
    cart_data = cart_data.filter((item) => item.id != itemId)
     // encontra o índice do item no array saved_cart_item
  const index = saved_cart_item.indexOf(itemId);

  if (index !== -1) {
    // Remove o item do array saved_cart_item
    saved_cart_item.splice(index, 1);

    // Remove o item do localStorage
    localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));

    // Remove o item do array cart_data
    cart_data = cart_data.filter((item) => item.id.toString() !== itemId.toString());

    updateCart()
  }



    updateCart()
}

// Increase Qty
function increaseQty(itemId) {
    const item = cart_data.find((item) => item.id == itemId)
    item.qty++;
   // Adiciona o item ao localStorage
   saved_cart_item.push(itemId);
   localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));
   
  updateCart()
}

// Decrease Qty
function decreaseQty(itemId) {
    //    cart_data = cart_data.map((item) => 
    //    item.id.toString() === itemId.toString()
    //    ? {...item, qty: item.qty > 1 ? item.qty -1 : item.qty}
    //    : item)
    
        const item = cart_data.find((item) => item.id == itemId)
        item.qty = Math.max(item.qty - 1, 0); 
    
     // encontra o índice do item no array saved_cart_item
     const index = saved_cart_item.indexOf(itemId);
    
     if (index !== -1) {
       // Remove o item do array saved_cart_item
       saved_cart_item.splice(index, 1);
    
       // Remove o item do localStorage
       localStorage.setItem('saved_cart_item', JSON.stringify(saved_cart_item));
    
       
       updateCart()
     }
    
        updateCart()
    
    }
    document.addEventListener('DOMContentLoaded', () => {
        const saved_cart_item = JSON.parse(localStorage.getItem('saved_cart_item')) || [];
        itemsNumber.innerText = saved_cart_item.length;
    });
// Calculate Items Number
function calculateItemsNum() {
    let itemsCount = 0

    cart_data.forEach((item) => (itemsCount += item.qty))

    itemsNumber.innerText = itemsCount
}
// Calculate Subtotal Price
function  calcSubtotalPrice() {
    let subtotal = 0
    cart_data.forEach((item) => (subtotal += item.price * item.qty))

    subtotalPrice.innerText = subtotal;
}  
// Render Items
function renderItems() {
    ITEMS.forEach((item, idx) =>{
        
        const itemEl = document.createElement('div');
        itemEl.classList.add('item');
        //itemEl.onclick = () => addItem(idx, item.id);
        const addToCartBtn = document.createElement('button');
        addToCartBtn.classList.add('btn2');
        addToCartBtn.textContent = 'Adicione ao Carrinho';
        addToCartBtn.addEventListener('click', () => addItem(idx, item.id));
        itemEl.innerHTML = `
        <img src="${item.image1}" alt="">
        <button class="btn1" onclick="gotoproduct(${item.id})">Veja Mais</button>
        `
        itemEl.appendChild(addToCartBtn);
        itemsEL.appendChild(itemEl);
        
    })
}

function gotoproduct(id){
    window.location.href = `indexmain.html?id=${id}`
}

//Display / Render Cart Items
function renderCartItems(){
    //remove everything from cart
    cartItems.innerHTML = '';
    // add new data
    cart_data.forEach((item) =>{
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart_item');
        cartItem.innerHTML = `  
        <div class="remove_item" onclick="removeCartItem(${item.id})">
                        <span>&times;</span>
                    </div>
                    <div class="item_img">
                        <img src="${item.image1}" alt="">
                    </div>
                    <div class="item_details">
                        <p>${item.name}</p>
                        <strong>$${item.price}</strong>
                        <div class="qty">
                            <span onclick="decreaseQty(${item.id})">-</span>
                            <strong>${item.qty}</strong>
                            <span onclick="increaseQty(${item.id})">+</span>
                        </div>
                    </div>
        `
        cartItems.appendChild(cartItem);
})
}

function updateCart(){
    //render cart items with updated data
    renderCartItems();
    //update items number in cart
    calculateItemsNum();
    //update subtotal price
    calcSubtotalPrice();
}